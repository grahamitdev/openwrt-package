#!/bin/sh

killall zigbeeserviceStart.sh zigbeeservice


/usr/bin/zigbeeservice
